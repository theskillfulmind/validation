const form = document.getElementById('form');
const username = document.getElementById('fullname');
const email = document.getElementById('email');
const phonenumber = document.getElementById('phonenumber');
const password = document.getElementById('password');
const password2 = document.getElementById('password2');

form.addEventListener('submit', e => {
	e.preventDefault();
	
	checkInputs();
});

function checkInputs() {
    //get the values from the inputs

	// trim to remove the whitespaces
	const fullnameValue = fullname.value.trim();
	const emailValue = email.value.trim();
    const phonenumberValue = phonenumber.value.trim();
    const passwordValue = password.value.trim();
	const password2Value = password2.value.trim();

    //check conditions for fullname
	if(fullnameValue === '') {
		setErrorFor(fullname, 'Name cannot be blank');
	} 
    else if(fullnameValue.length < 5) {
        setErrorFor(fullname, 'Name must not be less than 5 characters');
    }
    else if(!isName(fullnameValue)) {
        setErrorFor(fullname, 'Not a valid name');
    }
    else {
        if(isName(fullnameValue)) {
            const validname = removeSpaces(fullnameValue);
            if(validname.length < 5 )
                setErrorFor(fullname, 'Name must not be less than 5 characters');
            else
                setSuccessFor(fullname);
        }
	}

    //check conditions for email
	if(emailValue === '') {
		setErrorFor(email, 'Email cannot be blank');
	} 
    else if (!isEmail(emailValue)) {
		setErrorFor(email, 'Not a valid email');
	}
    else {
		setSuccessFor(email);
	}
	
    //check conditions for phone number
    if(phonenumberValue === '') {
		setErrorFor(phonenumber, 'Phone number cannot be blank');
	} 
    else if(phonenumberValue === '123456789'){
        setErrorFor(phonenumber, 'Phone number cannot be 123456789');
    } 
    else if(!isNumber(phonenumberValue)){
        setErrorFor(phonenumber, 'Phone number must be a 10-digit number');
    } 
    else {
        if(isNumber(phonenumberValue)) {
            setSuccessFor(phonenumber);
        }  
	}

    //check conditions for password
	if(passwordValue === '') {
		setErrorFor(password, 'Password cannot be blank');
	} 
    else if(passwordValue === 'password') {
        setErrorFor(password, 'Password cannot be "password"');
    }
    else if(passwordValue === fullnameValue) {
        setErrorFor(password, 'Password cannot be name of the user');
    }
    else if(passwordValue.length < 8) {
        setErrorFor(password, 'Password cannot be less than 8 characters');
    }
    else {
		setSuccessFor(password);
	}
	
    //check conditions for confirm password
	if(password2Value === '') {
		setErrorFor(password2, 'Confirm password cannot be blank');
	} 
    else if(passwordValue !== password2Value) {
		setErrorFor(password2, 'Passwords does not match');
	} 
    else{
		setSuccessFor(password2);
	}
}

function setErrorFor(input, message) {
	const formControl = input.parentElement;
	const small = formControl.querySelector('small');
	formControl.className = 'form-control error';
	small.innerText = message;
}

function setSuccessFor(input) {
	const formControl = input.parentElement;
	formControl.className = 'form-control success';
}
	
function isEmail(email) {
	return /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(email);
}

function isNumber(phonenumber) {
    var re = /^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/;
  
    return re.test(phonenumber);
}

function isName(fullname) {
    var reName = /(^[a-zA-Z][a-zA-Z\s]{0,20}[a-zA-Z]$)/;

    return reName.test(fullname); 
}

function removeSpaces(str) {
    return str.replace(/\s/g, '');
 }